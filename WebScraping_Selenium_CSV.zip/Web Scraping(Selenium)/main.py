import csv, time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from datetime import datetime
import xlsxwriter
workbook = xlsxwriter.Workbook('scrapResult.xlsx')

today = datetime.today().strftime('%A %d %b, %Y')
driver = webdriver.Chrome(r"C:\Users\116\.wdm\drivers\chromedriver\win32\90.0.4430.24\chromedriver.exe")

## ---------------------------------
driver.get("https://www.adamchoi.co.uk/")

def output3(title, worksheet):
    time.sleep(2)
    
    content = driver.find_element_by_id("desktop-streaks-table")
    rows = content.find_elements_by_xpath("./tbody/tr")  
    e_row = 0
    e_col = 0
    fieldnames = ['League', 'Stat', 'Next Match', 'Date', 'Streak']
    if title == "Corners":
        fieldnames = ['League', 'Stat', 'Next Match', 'Date', 'Number of matches']
    for item in (fieldnames):
        worksheet.write(e_row, e_col, item)
        e_col += 1
    
    for row in rows:
        e_row += 1
        worksheet.write(e_row, 0, row.find_elements_by_xpath("./td")[1].text)
        worksheet.write(e_row, 1, row.find_elements_by_xpath("./td")[2].text)
        worksheet.write(e_row, 2, row.find_elements_by_xpath("./td")[3].text)
        worksheet.write(e_row, 3, row.find_elements_by_xpath("./td")[4].text)
        
        temp = row.find_elements_by_xpath("./td")[2].text
        streak_value = 0
        index = temp.find("last", 0, len(temp))
        if title != "Corners" and index>-1:
            streak_value = temp[index+4: index+7]                
        if title == "Corners" and index>-1:
            streak_value = temp[index:len(temp)] 

        worksheet.write(e_row, 4, streak_value)
worksheet = workbook.add_worksheet('Popular')
output3("Popular", worksheet)
body_content = driver.find_element_by_id("page-wrapper")
nab = body_content.find_element_by_tag_name("ul")
nab.find_elements_by_xpath("./li/a")[1].click()
worksheet = workbook.add_worksheet('Unbeated')
output3("Unbeated", worksheet)
nab.find_elements_by_xpath("./li/a")[3].click()
worksheet = workbook.add_worksheet('Corners')
output3("Corners", worksheet)

## ---------------------------------
driver.get("https://www.adamchoi.co.uk/results/quick")
title = ['All Matches', 'Home Maches', 'Away Maches']

def output2(title, object, workbook):
    worksheet = workbook.add_worksheet(title)
    totaltbody = object.find_elements_by_xpath("./tbody")
    fieldnames = ['Team', '#', 'Percent', 'Time']
    e_row = 0
    e_col = 0
    for item in fieldnames:
        worksheet.write(e_row, e_col, item)
        e_col += 1
    for row in totaltbody:
        e_row += 1
        tdelments = row.find_elements_by_xpath("./tr/td")
        worksheet.write(e_row, 0, tdelments[1].text) 
        worksheet.write(e_row, 1, tdelments[2].text) 
        worksheet.write(e_row, 2, tdelments[3].find_element_by_class_name("percentagetext").text) 
        try:
            worksheet.write(e_row, 3, tdelments[5].find_element_by_tag_name("span").text) 
        except:
            pass

lenOfPage = driver.execute_script("window.scrollTo(0, document.body.scrollHeight);var lenOfPage=document.body.scrollHeight;return lenOfPage;")
match=False
while(match==False):
        lastCount = lenOfPage
        time.sleep(1)
        lenOfPage = driver.execute_script("window.scrollTo(0, document.body.scrollHeight);var lenOfPage=document.body.scrollHeight;return lenOfPage;")
        if lastCount==lenOfPage:
            match=True
for item, i in zip(title, range(3)):
    print("i = ", i)
    ele = driver.find_elements_by_class_name("table")
    output2(item, ele[i], workbook)

#------------------------------- 
driver.get("https://www.adamchoi.co.uk/fixtures")
title = ['BTTS', 'Over 1.5 Match Goals', 'Over 2.5 Match Goals', 'Over 9.5 Total Goals', 'Over 10.5 Total Goals', 'Over 6.5 cards']
def output1(title, workbook):
    time.sleep(2)
    worksheet = workbook.add_worksheet(title)
    container = driver.find_element_by_id('fixtures-container')
    panelContents = container.find_elements_by_class_name('panel')    
    print(len(panelContents))
    fieldnames = ['Leagues', 'Date', 'Home', 'All', 'Home Team', 'KO', 'Away Team', 'All_', 'Away']
    e_row = 0
    e_col = 0
    for item in fieldnames:
        worksheet.write(e_row, e_col, item)
        e_col += 1
    for panelContent in panelContents[2:]:
        panelHeading = panelContent.find_element_by_class_name('panel-heading')
        League = panelHeading.find_element_by_class_name('ng-binding').text
        tableBody = panelContent.find_element_by_tag_name("tbody")            
        for row in tableBody.find_elements_by_xpath('./tr'):
            
            tds = row.find_elements_by_tag_name('td')
            if len(tds)<2:
                Date = tds[0].text
            else:
                Home = tds[0].find_element_by_tag_name('span').text
                Away = tds[6].find_element_by_tag_name('span').text
                if (Date == today and Home >= '80%' and Home != 'N/A') or (Date == today and Away >= '80%' and Away != 'N/A'):
                    e_row += 1
                    worksheet.write(e_row, 0, League)
                    worksheet.write(e_row, 1, tds[0].text)
                    worksheet.write(e_row, 2, Home)
                    worksheet.write(e_row, 3, tds[1].find_element_by_tag_name('span').text)
                    worksheet.write(e_row, 4, tds[2].text)
                    worksheet.write(e_row, 5, tds[3].text)
                    worksheet.write(e_row, 6, tds[4].text)
                    worksheet.write(e_row, 7, tds[5].find_element_by_tag_name('span').text)
                    worksheet.write(e_row, 8, tds[6].find_element_by_tag_name('span').text)
                
output1('BTTS', workbook)
select1 = Select(driver.find_elements_by_tag_name('select')[0])
select2 = Select(driver.find_elements_by_tag_name('select')[1]) 
select1.select_by_visible_text('Total Match Goals')
output1('over2_5MatchGoals', workbook)
select2.select_by_visible_text('Over 1.5 Match Goals')
output1('over1_5MatchGoals', workbook)
select1.select_by_visible_text('Total Match Corners')
output1('over9_5TotalCorners', workbook)
select2.select_by_visible_text('Over 10.5 Total Corners')
output1('over10_5TotalCorners', workbook)
select1.select_by_visible_text('Total Cards')
output1('over6_5Cards', workbook)
driver.close()
workbook.close
